-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 22, 2015 at 09:15 AM
-- Server version: 5.1.30
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail_penjualan`
--

CREATE TABLE IF NOT EXISTS `detail_penjualan` (
  `NO_PENJ` varchar(10) NOT NULL,
  `KODE_BRG` varchar(10) NOT NULL,
  `HARGA_BRG` int(11) NOT NULL,
  `JUMLAH` int(11) NOT NULL,
  `SUBTOTAL` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_penjualan`
--

INSERT INTO `detail_penjualan` (`NO_PENJ`, `KODE_BRG`, `HARGA_BRG`, `JUMLAH`, `SUBTOTAL`) VALUES
('PNJ-0005', 'BRG-0001', 5600000, 1, 5600000),
('PNJ-0005', 'BRG-0003', 1450000, 2, 2900000),
('PNJ-0005', 'BRG-0004', 1090000, 1, 1090000),
('PNJ-0005', '', 0, 0, 0),
('PNJ-0005', 'BRG-0002', 1250000, 2, 2500000);

-- --------------------------------------------------------

--
-- Table structure for table `head_penjualan`
--

CREATE TABLE IF NOT EXISTS `head_penjualan` (
  `ID_PENJ` int(11) NOT NULL AUTO_INCREMENT,
  `NO_PENJ` varchar(10) NOT NULL,
  `TGL_PENJ` date NOT NULL,
  `NAMA_PEMB` varchar(30) NOT NULL,
  `NO_HP_PEMB` varchar(12) NOT NULL,
  PRIMARY KEY (`ID_PENJ`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=140 ;

--
-- Dumping data for table `head_penjualan`
--

INSERT INTO `head_penjualan` (`ID_PENJ`, `NO_PENJ`, `TGL_PENJ`, `NAMA_PEMB`, `NO_HP_PEMB`) VALUES
(135, 'PNJ-0001', '0000-00-00', 'Andi Rohandi', '089690428088'),
(138, 'PNJ-0004', '2015-03-22', 'safsdf', '10'),
(139, 'PNJ-0005', '2015-03-22', 'Andi Rohandi', '089690428088');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `ID_BRG` int(11) NOT NULL AUTO_INCREMENT,
  `KODE_BRG` varchar(10) NOT NULL,
  `NAMA_BRG` varchar(50) NOT NULL,
  `HARGA_BRG` int(11) NOT NULL,
  PRIMARY KEY (`ID_BRG`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`ID_BRG`, `KODE_BRG`, `NAMA_BRG`, `HARGA_BRG`) VALUES
(1, 'BRG-0001', 'HP Samsung Galaxy S4', 5600000),
(2, 'BRG-0002', 'HP Samsung Galaxy Star', 1250000),
(3, 'BRG-0003', 'Hp Samsung Galaxy Fame', 1450000),
(5, 'BRG-0004', 'HP Samsung Galaxy Star', 1090000),
(6, 'BRG-0005', 'HP Samsung Galaxy S3', 4800000),
(7, 'BRG-0006', 'HP Samsung Galaxy S2', 3500000),
(8, 'BRG-0007', 'HP Samsung DUOS', 3560000),
(9, 'BRG-0008', 'HP Samsung Cor 2', 2850000);
